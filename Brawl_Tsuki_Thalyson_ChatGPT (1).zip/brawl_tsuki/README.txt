BRAWL TSUKI
============

Protótipo inicial de um site profissional de guias de Brawl Stars.

Arquivos:
- index.html
- style.css
- script.js

Para testar, abra index.html no navegador.

A consulta por tag está preparada visualmente, mas precisa de uma API/backend para mostrar dados reais de jogadores.
