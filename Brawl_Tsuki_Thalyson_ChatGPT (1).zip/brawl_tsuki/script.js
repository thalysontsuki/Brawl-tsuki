const brawlers = [
  ["Shelly","Controle","🔫"],["Colt","Tiro","🤠"],["Spike","Controle","🌵"],["Leon","Assassino","🦎"],
  ["Crow","Assassino","🐦"],["Poco","Suporte","🎸"],["El Primo","Tanque","🥊"],["Charlie","Controle","🕷️"]
];

const grid = document.getElementById("brawlerGrid");
function render(list){
  grid.innerHTML = list.map(([name,role,emoji]) => `
    <article class="brawler" onclick="openBrawler('${name}')">
      <div class="avatar">${emoji}</div><h3>${name}</h3><div class="role">${role}</div>
    </article>`).join("");
}
render(brawlers);

document.getElementById("search").addEventListener("input", e=>{
  const q=e.target.value.toLowerCase();
  render(brawlers.filter(x=>x[0].toLowerCase().includes(q)));
});

function openBrawler(name){
  alert(`Brawl Tsuki\\n\\nGuia de ${name}\\n\\nAqui entraremos com estratégias, melhores builds, mapas e dicas.`);
}

document.getElementById("profileForm").addEventListener("submit", e=>{
  e.preventDefault();
  const tag=document.getElementById("tag").value.trim().toUpperCase();
  const box=document.getElementById("profileResult");
  if(!tag){box.textContent="Digite uma tag de jogador.";box.classList.remove("hidden");return;}
  box.innerHTML=`<strong>Perfil: ${tag}</strong><br><span style="color:#aeb2c0">Modo demonstração — a integração com a API do Brawl Stars será conectada aqui.</span>`;
  box.classList.remove("hidden");
});
